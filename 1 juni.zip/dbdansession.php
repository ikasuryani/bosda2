<?php
    //$link = mysql_connect("localhost","root","",'pimusv') or die("Koneksi Gagal");
   	//mysql_select_db($link,"pimusv") or die("Database select failed");
   // error_reporting(0);
   $link = mysql_connect('localhost', 'root', '');
	if (!$link) {
		die('Could not connect: ' . mysql_error());
	}
	else
	{
		//echo 'Connected successfully';
		mysql_select_db('bosda') or die("Database select failed");
	}
	//mysql_close($link);
?>