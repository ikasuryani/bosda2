<br>
<br>
<h2 style="margin-left: 25px;">Sistem Informasi Dana BOS - Sekolah</h2>
<div style="float: right; margin-right: -20px; text-align: right;">
<h4>
    <a href="profil.html"><i class="fa fa-user fa-fw"></i>Endang Soekamti</a>
</h4>
<br><p style="text-align: right;">Bendahara - SDN 001 Surabaya</p>
</div>